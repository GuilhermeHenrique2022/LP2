﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjetoReavaliação
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int[] vetorA = new int[10];
            vetorA[0] = 1;
            vetorA[1] = 2;
            vetorA[2] = 3;
            vetorA[3] = 4;
            vetorA[4] = 5;
            vetorA[5] = 6;
            vetorA[6] = 7;
            vetorA[7] = 8;
            vetorA[8] = 9;
            vetorA[9] = 10;

            int[] vetorB = new int[10];


        }

        private void btnInfoValor_Click(object sender, EventArgs e)
        {

            int i;
            int aux;
            for (i = 0; i < 10; i++)
            {
                if (i == 0)
                {
                    aux = int vetorA[i];
                    int vetorB[i]= aux * 5;
                }
                if else( i. == 2)
                {
                    aux = int vetorA[i];
                    int vetorB[i]= aux * 5;
                }
                 if else(i == 4)
                {
                    aux = int vetorA[i];
                    int vetorB[i]= aux * 5;
                }
                 if else (i == 6)
                {
                    aux = int vetorA[i];
                    int vetorB[i]= aux * 5;
                }
                if else(i == 8){
                    aux = int vetorA[i];
                    int vetorB[i] = aux + 5;
                }
                if else(i == 6)
                {
                    aux = int vetorA[i];
                    int vetorB[i]= aux * 5;
                }

        }
            for(i=0; i < 10; i++){
                lbxValores.Items.Add( int vetorA[i]);
                lbxValores.Items.Add( int vetorB[i] );
            }
    }
    }
}

