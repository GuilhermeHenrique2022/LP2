﻿namespace ProjetoReavaliação
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInfoValor = new System.Windows.Forms.Button();
            this.lbxValores = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnInfoValor
            // 
            this.btnInfoValor.Location = new System.Drawing.Point(164, 99);
            this.btnInfoValor.Name = "btnInfoValor";
            this.btnInfoValor.Size = new System.Drawing.Size(106, 71);
            this.btnInfoValor.TabIndex = 0;
            this.btnInfoValor.Text = "Informar Valores";
            this.btnInfoValor.UseVisualStyleBackColor = true;
            this.btnInfoValor.Click += new System.EventHandler(this.btnInfoValor_Click);
            // 
            // lbxValores
            // 
            this.lbxValores.FormattingEnabled = true;
            this.lbxValores.Location = new System.Drawing.Point(453, 120);
            this.lbxValores.Name = "lbxValores";
            this.lbxValores.Size = new System.Drawing.Size(375, 238);
            this.lbxValores.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(918, 412);
            this.Controls.Add(this.lbxValores);
            this.Controls.Add(this.btnInfoValor);
            this.Name = "Form1";
            this.Text = "Projeto Recuperação";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnInfoValor;
        private System.Windows.Forms.ListBox lbxValores;
    }
}

